package com.harish;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;


/**
 * Session Bean implementation class TestPrint
 */
@Startup
@Singleton
@LocalBean
public class ConsumerMainClass {

	/**
	 * Default constructor.
	 */
	// kafkaConsumer kafCon= new kafkaConsumer();
	CleanExitConsumer kafCon = new CleanExitConsumer();
	
	@PostConstruct
	public void IntializeConsumer() {
		System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Initializing Consumer @@@@@@@@@@@@@@@@@@@@@");
		kafCon.startListening();
		
	}
	@PreDestroy
	public  void DestroyConsumer (){
		System.out.println("$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ Calling interupt method @@@@@@@@@@@@@@@@@@@@@");
		kafCon.stopConsumer();
	}
}
