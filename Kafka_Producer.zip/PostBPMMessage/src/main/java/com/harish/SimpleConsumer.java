package com.harish;

import java.time.Duration;
import java.util.Collections;
//import util.properties packages
import java.util.Properties;

//import simple producer packages
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.Callback;
//import KafkaProducer packages
import org.apache.kafka.clients.producer.KafkaProducer;

//Consumer
import	org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
//import ProducerRecord packages
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



//Create java class named "SimpleProducer�
public class SimpleConsumer{

	public static void main(String[] args) throws Exception {
		/*
		 * // Check arguments length value if(args.length == 0){
		 * System.out.println("Enter topic name"); return; }
		 */
		Logger logger = LoggerFactory.getLogger(SimpleConsumer.class);
		logger.info( "Value :");
		// Assign topicName to string variable
		String topicName = "first_topic";

		// create instance for properties to access producer configs
		Properties props = new Properties();

		// Assign localhost id
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "kafka165.harishfysx.com:9092");
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG , StringDeserializer.class.getName());
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		props.put(ConsumerConfig.GROUP_ID_CONFIG, "my-fourth-applicaiton");
		props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG , "earliest");

	

		// Create Consumer
		KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(props);
		// Subscribe
		consumer.subscribe(Collections.singleton(topicName));
		//Poll data

		
		while(true) {
			ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(100));
			for (ConsumerRecord<String, String> record :  records) {
				logger.info( "Value :" + record.value());
				logger.info("Offset :" + record.offset());
			}
		}
	}
}