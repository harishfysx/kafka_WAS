package com.harish;

//import util.properties packages
import java.util.Properties;

//import simple producer packages
import org.apache.kafka.clients.producer.Producer;

//import KafkaProducer packages
import org.apache.kafka.clients.producer.KafkaProducer;

//import ProducerRecord packages
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;

//Create java class named "SimpleProducer�
public class SimpleProducer {

	public static void main(String[] args) throws Exception {
		/*
		 * // Check arguments length value if(args.length == 0){
		 * System.out.println("Enter topic name"); return; }
		 */
		// Assign topicName to string variable
		String topicName = "first_topic";

		// create instance for properties to access producer configs
		Properties props = new Properties();

		// Assign localhost id
		props.put("bootstrap.servers", "kafka165.harishfysx.com:9092");

		// Set acknowledgements for producer requests.
		props.put("acks", "all");

		// If the request fails, the producer can automatically retry,
		props.put("retries", 0);

		// Specify buffer size in config
		props.put("batch.size", 16384);

		// Reduce the no of requests less than 0
		props.put("linger.ms", 1);

		// The buffer.memory controls the total amount of memory available to the
		// producer for buffering.
		props.put("buffer.memory", 33554432);

		props.put("key.serializer", StringSerializer.class.getName());

		props.put("value.serializer", StringSerializer.class.getName());

		Producer<String, String> producer = new KafkaProducer<String, String>(props);

		for (int i = 0; i < 5000; i++) {
			String data= "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.";
			ProducerRecord <String, String> record= new ProducerRecord<String, String>(topicName, data);
			producer.send(record);
		}
			
		System.out.println("Message sent successfully");
		producer.close();
	}
}