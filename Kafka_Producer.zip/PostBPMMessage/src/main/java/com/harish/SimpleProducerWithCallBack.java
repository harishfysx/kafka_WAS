package com.harish;

//import util.properties packages
import java.util.Properties;

//import simple producer packages
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.Callback;
//import KafkaProducer packages
import org.apache.kafka.clients.producer.KafkaProducer;

//import ProducerRecord packages
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//Create java class named "SimpleProducer�
public class SimpleProducerWithCallBack{

	public static void main(String[] args) throws Exception {
		/*
		 * // Check arguments length value if(args.length == 0){
		 * System.out.println("Enter topic name"); return; }
		 */
		Logger logger = LoggerFactory.getLogger(SimpleProducerWithCallBack.class);
		logger.info( "Value :");
		// Assign topicName to string variable
		String topicName = "first_topic";

		// create instance for properties to access producer configs
		Properties props = new Properties();

		// Assign localhost id
		props.put("bootstrap.servers", "kafka165.harishfysx.com:9092");

		// Set acknowledgements for producer requests.
		props.put("acks", "all");

		// If the request fails, the producer can automatically retry,
		props.put("retries", 0);

		// Specify buffer size in config
		props.put("batch.size", 16384);

		// Reduce the no of requests less than 0
		props.put("linger.ms", 1);

		// The buffer.memory controls the total amount of memory available to the
		// producer for buffering.
		props.put("buffer.memory", 33554432);

		props.put("key.serializer", StringSerializer.class.getName());

		props.put("value.serializer", StringSerializer.class.getName());

		Producer<String, String> producer = new KafkaProducer<String, String>(props);

		for (int i = 0; i < 10; i++) {
			ProducerRecord <String, String> record= new ProducerRecord<String, String>(topicName, Integer.toString(i));
			producer.send(record, new Callback() {
				
				@Override
				public void onCompletion(RecordMetadata recMetaData, Exception e) {
			
					if(e == null) {
						logger.info("record sent success \n" +
						"Tpoic" + recMetaData.topic() + "\n" +
					    "Partition: "	+ recMetaData.partition()	+ "\n" +	
						"Offset:" + recMetaData.offset()+ "\n" +
					    "TimeStamp:"+ recMetaData.timestamp());
					} else {
						logger.error("Error is : ", e);
					}
				}
			});
		}
			
		System.out.println("Message sent successfully");
		producer.close();
	}
}