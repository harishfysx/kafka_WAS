package com.harish;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.time.Duration;
import java.util.Collections;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.errors.WakeupException;
import org.apache.kafka.common.serialization.StringDeserializer;

//JMS 


import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSession;
import javax.jms.TextMessage;

public class CleanExitConsumer {

	private final KafkaConsumer<String, String> consumer;
	private final ExecutorService executor;
	private final CountDownLatch latch;
	Properties external_props = new Properties();

	public void loadExteranlProps() {
		String rootPath = Thread.currentThread().getContextClassLoader()
				.getResource("").getPath();
		String appConfigPath = rootPath + "appprops.xml";

		try {

			external_props.loadFromXML(new FileInputStream(appConfigPath));

		} catch (IOException ex) {
			System.out.println("Error on IOEXcepton");
		}

	}

	public CleanExitConsumer() {
		loadExteranlProps();
		consumer = new KafkaConsumer<>(getDefaultProperties());
		latch = new CountDownLatch(1);
		executor = Executors.newSingleThreadExecutor();
	}

	private Properties getDefaultProperties() {

		Properties properties = new Properties();
		properties.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,
				external_props.getProperty("kafka_bootstrap_server"));
		properties.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
				StringDeserializer.class.getName());
		properties.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
				StringDeserializer.class.getName());
		properties.setProperty(ConsumerConfig.GROUP_ID_CONFIG, external_props.getProperty("kafka_group_id"));
		properties.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,
				"earliest");

		return properties;
	}

	public void startListening() {

		System.out.println("Starts Listen Task");
		executor.submit(getListenTask(external_props.getProperty("kafka_topic")));

	}

	private Runnable getListenTask(String topic) {
		return () -> {
			addShutDownHook();
			consumer.subscribe(Collections.singletonList(topic));

			try {
				while (true) {

					pollRecords();
				}

			} catch (WakeupException ex) {
				System.out.println("Wake up received");
			} finally {
				consumer.close();
				System.out.println("consumer is closed");
				latch.countDown();
			}
		};
	}

	private void pollRecords() {
		// System.out.println("polling");
		ConsumerRecords<String, String> records = consumer.poll(Duration
				.ofMillis(200));
		// records.forEach(record -> System.out.println(record.toString()));
		for (ConsumerRecord<String, String> record : records) {
			// logger.info( "Value :" + record.value());
			// logger.info("Offset :" + record.offset());
			System.out.println("Value :" + record.value());
			System.out.println("Offset :" + record.offset());
			System.out.println(record.toString());
			String msgId = record.partition() + "_"+ record.offset();
			try {
				postMessagetoBPM(msgId, record.value());
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				System.out.println("NamingException in pollRecords"
						+ e.toString());
				// e.printStackTrace();
			} catch (JMSException e) {
				// TODO Auto-generated catch block
				System.out
						.println("JMSException in pollRecords" + e.toString());
			}
		}
	}

	private void addShutDownHook() {
		Runtime.getRuntime().addShutdownHook(new Thread(() -> {
			System.out.println("Shutdown is caught");
			stopConsumer();
			closeExecutor();
		}));
	}

	public void stopConsumer() {
		consumer.wakeup();
		try {
			latch.await();
		} catch (InterruptedException e) {
			System.out.println("Barrier wait is interrupted");
		}
	}

	public void closeExecutor() {
		executor.shutdownNow();
		try {
			executor.awaitTermination(5, TimeUnit.SECONDS);
		} catch (InterruptedException e) {
			System.out.println("Could not shutdown executor");
			executor.shutdownNow();
			Thread.currentThread().interrupt();
		}
	}

	public void postMessagetoBPM(String messageId,String kafkaMsg) throws NamingException, JMSException {

		Queue ucaqueue;
		QueueConnectionFactory ucaqcf;
		QueueConnection connection = null;
		QueueSession session = null;
		
		
		
		String data = "<eventmsg><event processApp=\"" + external_props.getProperty("process_app_acronym") +"\"  ucaname=\""+  external_props.getProperty("start_uca_name")+"\">"+ external_props.getProperty("uca_event_message") +"</event><parameters><parameter><key>"+external_props.getProperty("uca_complexInput")+"</key><value><messageIdentifier>"
				+ messageId
				+ "</messageIdentifier><object>"
				+ kafkaMsg
				+ "</object></value></parameter></parameters></eventmsg>";
		
		try {
			InitialContext ctx = new InitialContext();
			ucaqcf = (QueueConnectionFactory) ctx
					.lookup("javax.jms.QueueConnectionFactory");
			ucaqueue = (Queue) ctx.lookup("jms/eventqueue");
			System.out.println("ucaqueue:: " + ucaqueue);
			connection = ucaqcf.createQueueConnection(external_props.getProperty("jms_cred_usrname"), external_props.getProperty("jms_cred_password"));
			System.out.println("QCF:: " + ucaqcf + " queueconnection:: "
					+ connection);
			session = connection.createQueueSession(false,
					Session.AUTO_ACKNOWLEDGE);
			System.out.println("session:: " + session);
			MessageProducer producer = session.createProducer(ucaqueue);
			TextMessage message = session.createTextMessage();
			message.setText(data);
			System.out.println("Message:: " + message);
			System.out.println("Message:: " + message.getText());
			producer.send(message);
			System.out.println("UCAMessage Sent to creditScoreMessage dynamically");
			producer.close();
			session.close();
			connection.close();
		} finally {
			if (session != null) {
				session.close();
			}

			if (connection != null) {
				connection.close();
			}
		}
	}

}
